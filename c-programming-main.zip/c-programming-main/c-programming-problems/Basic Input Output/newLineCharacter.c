// C Program to Print Hello in First Line And Aman in Second Line


//Header files
#include<stdio.h>
#include<conio.h>


// Main Function Start
int main(){

    printf("Hello\nAman\n");  // '\n' is used to Add New Line

    getch(); 
    return 0;
}
// Main Function End
