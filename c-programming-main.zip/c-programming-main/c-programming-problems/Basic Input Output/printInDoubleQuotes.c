// C Program to Print WebWithAman in Double Quotes => "WebWithAman"


// Header files
#include <stdio.h>
#include <conio.h>


// Main Function Start
int main()
{

    // 1st Approach
    printf(" \"WebWithAman\" "); //  '\"' is a Escape Charcter used to Print (") Double Quotes


    // 2nd Approach
    // char ch='"';
    // printf("%cWebWithAman%c",ch,ch);

    getch();
    return 0;
}
// Main Function End
