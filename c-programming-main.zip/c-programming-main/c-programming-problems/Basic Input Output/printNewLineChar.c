// C Program to Print Newline Character => '\n'


//Header files
#include<stdio.h>
#include<conio.h>


// Main Function Start
int main(){

    printf(" \\n "); 

    getch(); 
    return 0;
}
// Main Function End
