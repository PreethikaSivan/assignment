// C Program to Print Percent Sign % On Screen


//Header files
#include<stdio.h>
#include<conio.h>


// Main Function Start
int main(){

    // 1st Approach
    printf(" %% "); 

    // 2nd Approach
    // char ch = '%';
    // printf("%c",ch);

    getch(); 
    return 0;
}
// Main Function End
