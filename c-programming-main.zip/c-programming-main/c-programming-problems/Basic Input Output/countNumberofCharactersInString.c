// C Program to count Number of Characters in this String => “C Programming” Using printf() Function.


// Header files
#include <stdio.h>
#include <conio.h>

 
// Main Function Start
int main()
{

    int numberOfCharacters = printf("C Programming"); // Space will also taken as character

    printf("\nThere Are %d Characters in \"C Programming\"",numberOfCharacters);

    getch();
    return 0;
}
// Main Function End