// C Program to Print WebWithAman On Screen


//Header files
#include<stdio.h>
#include<conio.h>


// Main Function Start
int main(){

    printf("WebWithAman\n");  // printf() Function is Used to Print Output On Screen

    getch(); 
    return 0;
}
// Main Function End
