// C Program to Print %d On Screen


//Header files
#include<stdio.h>
#include<conio.h>


// Main Function Start
int main(){

    // 1st Approach
    printf(" %%d "); 

    // 2nd Approach
    // char ch = '%';
    // printf("%cd",ch);

    getch(); 
    return 0;
}
// Main Function End
