// C Program to Find Length of String Using printf() function


// Header files
#include <stdio.h>
#include <conio.h>

// Main Function Start
int main()
{

    int length = printf("WebWithAman"); // printf() Returns Number of Characters Successfully Printed On Screen

    printf("\nTotal Characters in \"WebWithAman\" => %d\n",length);

    getch();
    return 0;
}
// Main Function End
