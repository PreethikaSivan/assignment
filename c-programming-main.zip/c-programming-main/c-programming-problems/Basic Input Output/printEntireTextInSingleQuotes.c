// C Program to Print the entire text as it is on screen in single quotes => ‘Hello, this is forward slash (/) , this is back slash (\) and this is single quote (‘) ‘


// Header files
#include <stdio.h>
#include <conio.h>


// Main Function Start
int main()
{

    printf("\'Hello, this is forward slash (/), this is back slash (\\) and this is single quote (\')\'");

    getch();
    return 0;
}
// Main Function End
